#include <stdio.h>
#include <math.h>
 
int main(void) {
    int n, operations;
    double numerator, summ;
    summ = 0;
    operations = 0;
    printf("Input n: ");
    scanf("%d", &n);
    double denominator = 1.0;
    

    for (int i = 1; i <= n; i++) { // 1(операція j <= i) + 1(операція j++) = 2 
        denominator *= log(i + 2);
        numerator = 3.0 - sin(i)*sin(i);

        summ += numerator / denominator;

        operations += 13; // 2(зовнішній цикл) + 1(операція x *=) + 1(операція ln()) + 2(oneрація + 2) + 3(oперація 3.0 - x ) + 1(операція sin(n)) + 1(операція x^2) + 1(операція +=) + 1(операція numerator / denominator) = 13
    }
    printf("S = %lf\n", summ);
    printf("S = %d\n", operations);

    return 0;
}